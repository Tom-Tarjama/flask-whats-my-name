from flask import Flask, render_template, request, redirect

whats_my_name = Flask(__name__)

@whats_my_name.route('/')
def landing_page():
	return render_template("index.html")

@whats_my_name.route('/process', methods=['POST'])
def submit():
	user_name = request.form['name']
	print user_name
	return redirect('/')

whats_my_name.run(debug=True)
